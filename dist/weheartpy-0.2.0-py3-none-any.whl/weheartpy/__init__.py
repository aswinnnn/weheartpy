# __init__.py

from .weheartpy import WeHeartIt
import weheartpy

